package com.sparks.datatest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Datatest1Application {

	public static void main(String[] args) {
		SpringApplication.run(Datatest1Application.class, args);
	}

}
